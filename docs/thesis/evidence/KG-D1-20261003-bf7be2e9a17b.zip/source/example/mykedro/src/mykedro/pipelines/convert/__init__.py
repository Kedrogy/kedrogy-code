"""
This is a boilerplate pipeline 'convert'
generated using Kedro 1.2.0
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
