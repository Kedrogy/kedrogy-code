# Kedrogy Draft 1 source evidence

Snapshot: KG-D1-20261003-bf7be2e9a17b
Captured: 3 October 2026
Base commit: bcfde46a6ccd8a238a0a239831aab0213f042795

This archive preserves selected source and documentation files used to verify the implementation descriptions in Thesis Manuscript Draft 1. It includes the captured working-copy changes, so checking out the base commit alone will not reconstruct it. Paths are relative to the repository root; manifest.json records SHA-256 hashes for every captured file.

The selection is evidence for source inspection, not a complete runnable environment or a record of successful tests. It excludes environment credentials, runtime datasets, annotations, model weights and unrelated assets. The author holds this private evidence archive with the thesis materials and can make it available to the supervisor.
